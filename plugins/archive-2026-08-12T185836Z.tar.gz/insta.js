const axios = require('axios');

module.exports = {
    command: ['ig', 'instagram', 'insta'],
    description: 'Download Instagram Reels/Videos',
    ownerOnly: false,

    handler: async ({ socket, msg, sender, args, body, prefix }) => {
        try {
            // Get URL from args
            const url = args[0];

            if (!url || !url.includes('instagram.com')) {
                return await socket.sendMessage(sender, {
                    text: `❌ *Usage:* ${prefix}ig <instagram_url>\n\n*Example:*\n${prefix}ig https://www.instagram.com/reel/xxxxx/`
                }, { quoted: msg });
            }

            // Send loading message
            await socket.sendMessage(sender, {
                react: { text: '⏳', key: msg.key }
            });

            await socket.sendMessage(sender, {
                text: '🔄 *Downloading Instagram video...*'
            }, { quoted: msg });

            // Call API
            const apiUrl = `https://apis.davidcyriltech.my.id/instagram?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl, { timeout: 15000 });
            const data = response.data;

            if (!data.success || !data.result) {
                return await socket.sendMessage(sender, {
                    text: '❌ *Failed to fetch video. Try again later.*'
                }, { quoted: msg });
            }

            const result = data.result;
            const videoUrl = result.video;
            const thumbnail = result.thumbnail;
            const title = result.title || 'Instagram Video';
            const likes = result.likeCount ? `❤️ ${result.likeCount.toLocaleString()}` : '';
            const comments = result.commentCount ? `💬 ${result.commentCount.toLocaleString()}` : '';
            const quality = result.quality || '';

            if (!videoUrl) {
                return await socket.sendMessage(sender, {
                    text: '❌ *No video found for this URL.*'
                }, { quoted: msg });
            }

            // Build caption
            const shortTitle = title.length > 200 ? title.substring(0, 200) + '...' : title;
            const caption = `🎬 *VORTEX MD | Instagram Downloader*\n\n📝 ${shortTitle}\n\n${likes}  ${comments}\n📺 Quality: ${quality}\n\n> *Powered by VORTEX MD*`;

            // Send video
            await socket.sendMessage(sender, {
                video: { url: videoUrl },
                caption: caption,
                mimetype: 'video/mp4'
            }, { quoted: msg });

            // React done
            await socket.sendMessage(sender, {
                react: { text: '✅', key: msg.key }
            });

        } catch (err) {
            console.error('Instagram plugin error:', err.message);
            await socket.sendMessage(sender, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: msg });
        }
    }
};
