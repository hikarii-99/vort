const axios = require('axios');

module.exports = {
    command: ['video', 'ytdl', 'youtube', 'ytmp4'],
    description: 'Download YouTube Videos (Video/Document format)',
    ownerOnly: false,

    handler: async ({ socket, msg, sender, args, prefix }) => {
        try {
            const url = args[0];

            // YouTube Link එකක්ද කියලා බලන Regex එක
            const ytRegex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i;

            if (!url || !ytRegex.test(url)) {
                return await socket.sendMessage(sender, {
                    text: `❌ *Usage:* ${prefix}yt <youtube_url>\n\n*Example:*\n${prefix}yt https://youtu.be/xxxxx`
                }, { quoted: msg });
            }

            await socket.sendMessage(sender, {
                react: { text: '⏳', key: msg.key }
            });

            // API Call එක
            const apiUrl = `https://ytdl.udmodzz.workers.dev/?url=${encodeURIComponent(url)}&type=vid`;
            const response = await axios.get(apiUrl, { timeout: 20000 });
            const data = response.data;

            // API එකෙන් හරියට Data ආවද බලනවා
            if (!data || !data.links) {
                return await socket.sendMessage(sender, {
                    text: '❌ *Failed to fetch YouTube video. Check your link or try again later.*'
                }, { quoted: msg });
            }

            const title = data.videoname ? data.videoname.trim() : 'YouTube Video';
            const desc = data.desc ? data.desc.replace(/[\r\n]+/g, ' ').trim() : '';
            const shortDesc = desc.length > 100 ? desc.substring(0, 100) + '...' : desc || 'No Description';
            const thumbnail = data.thumbnail;
            
            // API එකේ "HD Video" කියලා තියෙන link එක අරගන්නවා (නැත්නම් පළවෙනි link එක ගන්නවා)
            const videoUrl = data.links["HD Video"] || Object.values(data.links)[0];

            if (!videoUrl) {
                return await socket.sendMessage(sender, {
                    text: '❌ *No video download links found for this URL.*'
                }, { quoted: msg });
            }

            // Thumbnail එකත් එක්ක යවන Menu Message එක
            const caption = `*╭━━━⊰✨ YOUTUBE DOWNLOADER ✨⊱━━━╮*\n\n┃ 📌 *Title:* ${title}\n┃ 📝 *Desc:* ${shortDesc}\n\n*╰━━━━━━━━━━━━━━━━━━━━━━╯*\n\n*🌐 DOWNLOAD OPTIONS:*\n\n  1️⃣  *Video Format (MP4)*\n  2️⃣  *Document Format (MP4)*\n\n*📥 Please reply with 1 or 2 to start the download.*`;

            // Thumbnail Image එකත් එක්ක Message එක යැවීම
            const sentMsg = await socket.sendMessage(sender, {
                image: { url: thumbnail },
                caption: caption
            }, { quoted: msg });

            const messageID = sentMsg.key.id;

            // ==========================================
            // Reply අල්ලගන්න Event Listener (Memory Safe)
            // ==========================================
            const listener = async (msgData) => {
                const receivedMsg = msgData.messages[0];
                if (!receivedMsg.message) return;

                const receivedText = receivedMsg.message.conversation || receivedMsg.message.extendedTextMessage?.text;
                const senderID = receivedMsg.key.remoteJid;

                // User Reply කරලා තියෙන්නේ Bot යවපු Menu එකටද කියලා බලනවා
                const isReplyToBot = receivedMsg.message.extendedTextMessage?.contextInfo?.stanzaId === messageID;

                if (isReplyToBot) {
                    await socket.sendMessage(senderID, {
                        react: { text: '⬇️', key: receivedMsg.key }
                    });

                    // 1 තේරුවොත් - Normal Video එකක් විදියට
                    if (receivedText === "1") {
                        await socket.sendMessage(senderID, {
                            video: { url: videoUrl },
                            caption: `🎬 *${title}*\n\n> *Downloaded by VORTEX-MD*`,
                            mimetype: 'video/mp4'
                        }, { quoted: receivedMsg });
                    } 
                    // 2 තේරුවොත් - Document Format එකක් විදියට
                    else if (receivedText === "2") {
                        await socket.sendMessage(senderID, {
                            document: { url: videoUrl },
                            mimetype: 'video/mp4',
                            fileName: `${title}.mp4`, // Document එකේ නම
                            caption: `📄 *${title}*\n\n> *Downloaded by VORTEX-MD*`
                        }, { quoted: receivedMsg });
                    } 
                    else {
                        return await socket.sendMessage(senderID, {
                            text: "❌ Invalid option! Please reply with 1 or 2."
                        }, { quoted: receivedMsg });
                    }

                    // සර්ථකව යැවූ පසු Event Listener එක Off කිරීම
                    socket.ev.off("messages.upsert", listener);
                    clearTimeout(timeout);
                }
            };

            // Listener එක On කිරීම
            socket.ev.on("messages.upsert", listener);

            // විනාඩි 5කින් Auto Off වෙන Timeout එක (RAM Safe)
            const timeout = setTimeout(() => {
                socket.ev.off("messages.upsert", listener);
            }, 5 * 60 * 1000);

        } catch (err) {
            console.error('YouTube plugin error:', err.message);
            await socket.sendMessage(sender, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: msg });
        }
    }
};
