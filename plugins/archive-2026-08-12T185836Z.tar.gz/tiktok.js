const axios = require('axios');

module.exports = {
    command: ['tiktok', 'tt', 'ttdl'],
    description: 'Download TikTok Videos or Audio',
    ownerOnly: false,

    handler: async ({ socket, msg, sender, args, prefix }) => {
        try {
            const url = args[0];

            // Link එකක් දීලා තියෙනවද සහ ඒක TikTok Link එකක්ද බලනවා
            const ttRegex = /(?:https?:\/\/)?(?:www\.|vt\.|vm\.)?tiktok\.com\/.+/i;

            if (!url || !ttRegex.test(url)) {
                return await socket.sendMessage(sender, {
                    text: `❌ *Usage:* ${prefix}tiktok <tiktok_url>\n\n*Example:*\n${prefix}tiktok https://vm.tiktok.com/xxxxx/`
                }, { quoted: msg });
            }

            await socket.sendMessage(sender, {
                react: { text: '⏳', key: msg.key }
            });

            // API Call එක (TikTok v3 API)
            const apiUrl = `https://apis.davidcyriltech.my.id/download/tiktokv3?url=${encodeURIComponent(url)}`;
            const response = await axios.get(apiUrl, { timeout: 15000 });
            const data = response.data;

            if (!data || !data.success || !data.video) {
                return await socket.sendMessage(sender, {
                    text: '❌ *Failed to fetch TikTok video. Check your link or try again later.*'
                }, { quoted: msg });
            }

            const author = data.author || 'Unknown Author';
            const description = data.description ? data.description.replace(/[\r\n]+/g, ' ').trim() : 'TikTok Video';
            const shortDesc = description.length > 150 ? description.substring(0, 150) + '...' : description;
            const videoUrl = data.video;
            const audioUrl = data.audio;

            // Menu Caption එක
            const caption = `*╭━━━⊰✨ TIKTOK DOWNLOADER ✨⊱━━━╮*\n\n┃ 👤 *Author:* ${author}\n┃ 📝 *Desc:* ${shortDesc}\n\n*╰━━━━━━━━━━━━━━━━━━━━━━╯*\n\n*🌐 DOWNLOAD OPTIONS:*\n\n  1️⃣  *Video (MP4)*\n  2️⃣  *Audio (MP3)*\n\n*📥 Please reply with 1 or 2 to start the download.*`;

            // Menu Message එක යැවීම
            const sentMsg = await socket.sendMessage(sender, {
                text: caption
            }, { quoted: msg });

            const messageID = sentMsg.key.id;

            // ==========================================
            // Reply එක අල්ලගන්න Event Listener එක
            // ==========================================
            const listener = async (msgData) => {
                const receivedMsg = msgData.messages[0];
                if (!receivedMsg.message) return;

                const receivedText = receivedMsg.message.conversation || receivedMsg.message.extendedTextMessage?.text;
                const senderID = receivedMsg.key.remoteJid;

                // User Reply කරලා තියෙන්නේ Bot ගේ Menu Message එකටද කියලා බලනවා
                const isReplyToBot = receivedMsg.message.extendedTextMessage?.contextInfo?.stanzaId === messageID;

                if (isReplyToBot) {
                    await socket.sendMessage(senderID, {
                        react: { text: '⬇️', key: receivedMsg.key }
                    });

                    // 1 තේරුවොත් - Video එක
                    if (receivedText === "1") {
                        await socket.sendMessage(senderID, {
                            video: { url: videoUrl },
                            caption: `📥 *TikTok Video Downloaded | VORTEX-MD*`,
                            mimetype: 'video/mp4'
                        }, { quoted: receivedMsg });
                    } 
                    // 2 තේරුවොත් - Audio එක
                    else if (receivedText === "2") {
                        if (!audioUrl) {
                            return await socket.sendMessage(senderID, {
                                text: "❌ Audio is not available for this video."
                            }, { quoted: receivedMsg });
                        }

                        await socket.sendMessage(senderID, {
                            audio: { url: audioUrl },
                            mimetype: 'audio/mpeg'
                        }, { quoted: receivedMsg });
                    } 
                    else {
                        return await socket.sendMessage(senderID, {
                            text: "❌ Invalid option! Please reply with 1 or 2."
                        }, { quoted: receivedMsg });
                    }

                    // සර්ථකව යැවූ පසු Event Listener එක Off කිරීම
                    socket.ev.off("messages.upsert", listener);
                    clearTimeout(timeout);
                }
            };

            // Listener එක On කිරීම
            socket.ev.on("messages.upsert", listener);

            // විනාඩි 5කින් Auto Off වෙන Timeout එක (RAM Safe)
            const timeout = setTimeout(() => {
                socket.ev.off("messages.upsert", listener);
            }, 5 * 60 * 1000);

        } catch (err) {
            console.error('TikTok plugin error:', err.message);
            await socket.sendMessage(sender, {
                text: `❌ *Error:* ${err.message}`
            }, { quoted: msg });
        }
    }
};
