const os = require('os');

module.exports = {
    command: ['menu', 'help', 'list', 'panel'],
    description: 'Show interactive menu system',
    ownerOnly: false,

    handler: async ({ socket, msg, sender, prefix }) => {
        try {
            // Show loading reaction
            await socket.sendMessage(sender, {
                react: { text: '⏳', key: msg.key }
            });

            // RAM Usage එක හරියටම ගණනය කිරීම
            const usedRAM = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
            const totalRAM = Math.round(os.totalmem() / 1024 / 1024);
            
            // Config එක අයින් කරපු නිසා Mode එක කෙලින්ම මෙතනින් දෙනවා
            const mode = 'Public'; 

            const menuCaption = `╭━━━〔 *VORTEX MD* 〕━━━┈⊷
┃★╭──────────────
┃★│ 👑 Owner : *Pansilu Nethmina*
┃★│ 💻 Type : *NodeJs*
┃★│ 🎲 Ram usage: *${usedRAM}MB / ${totalRAM}MB*
┃★│ ⚙️ Mode : *[${mode}]* 
┃★│ 🔣 Prefix : *${prefix}* 
┃★│ 🏷️ Version : *1.0 Beta* 
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╭━━〔 *Menu List* 〕━━┈⊷
┃◈╭─────────────·๏ 
┃◈│01.  *Download Menu* 
┃◈│02.  *Group Menu* 
┃◈│03.  *Fun Menu* 
┃◈│04.  *Owner Menu* 
┃◈│05.  *AI Menu* 
┃◈│06.  *Anime Menu* 
┃◈│07.  *Convert Menu* 
┃◈│08.  *Other Menu* 
┃◈│09.  *Logo Menu* 
┃◈│10.  *Main Menu* 
┃◈╰───────────┈⊷ 
╰──────────────┈⊷ 
╔══════════⚔️═══════════╗ 
          *Made by Pansilu Nethmina* 
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄 
╚══════════⚔️═══════════╝`;

            // Forwarded (Newsletter) Style
            const contextInfo = {
                mentionedJid: [sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363399456492644@newsletter',
                    newsletterName: 'VORTEX MD',
                    serverMessageId: 143
                }
            };

            // Main Menu Message එක යැවීම
            const sentMsg = await socket.sendMessage(
                sender,
                {
                    image: { url: 'https://files.catbox.moe/jcx2qo.jpg' },
                    caption: menuCaption,
                    contextInfo: contextInfo
                },
                { quoted: msg }
            );

            const messageID = sentMsg.key.id;

            // Complete menu data
            const menuData = {
                '1': {
                    title: "📥 *Download Menu* 📥",
                    content: `
╭━━━〔 *Download Menu* 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ *Social Media* ❤️
┃★│ • fb [url]
┃★│ • mediafire [url]
┃★│ • tt [url]
┃★│ • twitter [url]
┃★│ • Ig [url]
┃★│ • apk [app]
┃★│ • img [query]
┃★│ • dl [url]
┃★│ • pin [url]
┃★│ • modapk [app]
┃★│ • gdrive [url]
┃★│ • upload [url]
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ *Music/Video* ❤️
┃★│ • spotify [query]
┃★│ • song [song]
┃★│ • song2 [song]
┃★│ • video [Name]
┃★│ • Video2 [Name]
┃★│ • cine [url]
┃★│ • ytmp3 [url]
┃★│ • ytmp4 [url]
┃★│ • song [name]
┃★│ • sinhala [name]
┃★│ • movie [name]
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝ `,
                    image: 'https://files.catbox.moe/r2jp1i.jpg'
                },
                '2': {
                    title: "👥 *Group Menu* 👥",
                    content: `
╭━━━〔 *Group Menu* 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ *Management* ❤️
┃★│ • grouplink
┃★│ • kickall
┃★│ • add @user
┃★│ • remove @user
┃★│ • kick @user
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ *Admin Tools* ❤️
┃★│ • promote @user
┃★│ • demote @user
┃★│ • dismiss 
┃★│ • revoke
┃★│ • mute [time]
┃★│ • unmute
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ *Tagging* ❤️
┃★│ • tag @user
┃★│ • hidetag [msg]
┃★│ • tagall
┃★│ • tagadmins
┃★│ • invite
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
            ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/8460ga.jpg'
                },
                '3': {
                    title: "😄 *Fun Menu* 😄",
                    content: `
╭━━━〔 *Fun Menu* 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ *Interactive* ❤️
┃★│ • shapar
┃★│ • rate @user
┃★│ • insult @user
┃★│ • hack @user
┃★│ • ship @user1 @user2
┃★│ • character
┃★│ • pickup
┃★│ • joke
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ *Reactions* ❤️
┃★│ • hrt
┃★│ • hpy
┃★│ • syd
┃★│ • anger
┃★│ • shy
┃★│ • kiss
┃★│ • mon
┃★│ • cunfuzed
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
         *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/jwpwj4.jpg'
                },
                '4': {
                    title: "👑 Owner Menu 👑",
                    content: `
╭━━━〔 Owner Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Restricted ❤️
┃★│ • block @user
┃★│ • unblock @user
┃★│ • fullpp [img]
┃★│ • setpp [img]
┃★│ • restart
┃★│ • system
┃★│ • uptime
┃★│ • vv
┃★│ • getpp [Number]
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Info Tools ❤️
┃★│ • gjid
┃★│ • jid @user
┃★│ • list
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/d90r6e.jpg'
                },
                '5': {
                    title: "🤖 AI Menu 🤖",
                    content: `
╭━━━〔 AI Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Chat AI ❤️
┃★│ • ai [query]
┃★│ • gpt [query]
┃★│ • openai [query]
┃★│ • deepseek [query]
┃★│ • meta [query]
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Image AI ❤️
┃★│ • flux [text]
┃★│ • gen2 [text]
┃★│ • imagine2 [text]
┃★│ • imagine3 [text]
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/zkvui4.jpg'
                },
                '6': {
                    title: "🎎 Anime Menu 🎎",
                    content: `
╭━━━〔 Anime Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Images ❤️
┃★│ • awoo
┃★│ • waifu
┃★│ • neko
┃★│ • megnumin
┃★│ • maid
┃★│ • loli
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Other ❤️
┃★│ • ani [text]
┃★│ • anidt [url]
┃★│ • anid [url]
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/hy0bmr.jpg'
                },
                '7': {
                    title: "🔄 Convert Menu 🔄",
                    content: `
╭━━━〔 Convert Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Media ❤️
┃★│ • sticker [img]
┃★│ • toimg [img]
┃★│ • emojimix 😎+😂
┃★│ • tomp3 [video]
┃★│ • tourl [media]
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Text ❤️
┃★│ • fancy [text]
┃★│ • tts [text]
┃★│ • trt [text]
┃★│ • aivoice [text]
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/son2ny.jpg'
                },
                '8': {
                    title: "📌 Other Menu 📌",
                    content: `
╭━━━〔 Other Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Other ❤️
┃★│ • Save
┃★│ • fwd [gjid]
┃★│ • ttstalk [id]
┃★│ • gitstalk [username]
┃★│ • hirunews
┃★│ • itnnews
┃★│ • removebg [image]
┃★│ • cpp
┃★│ • wallpaper
┃★│ • profile
┃★│ • chr [LINK], reacts
┃★│ • fetch [API URL]
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Search ❤️
┃★│ • tiks [text]
┃★│ • news [query]
┃★│ • img [text
┃★│ • weather [loc]
┃★│ • lyric
┃★│ • rtik [text]
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/9jzx6b.jpg'
                },
                '9': {
                    title: "💞 Logo Menu 💞",
                    content: `
╭━━〔 *Logo List* 〕━━┈⊷
┃◈╭─────────────·๏
┃◈┃• neonlight
┃◈┃• blackpink
┃◈┃• dragonball
┃◈┃• 3dcomic
┃◈┃• america
┃◈┃• naruto
┃◈┃• sadgirl
┃◈┃• clouds
┃◈┃• futuristic
┃◈┃• 3dpaper
┃◈┃• eraser
┃◈┃• sunset
┃◈┃• leaf
┃◈┃• galaxy
┃◈┃• sans
┃◈┃• boom
┃◈┃• hacker
┃◈┃• devilwings
┃◈┃• nigeria
┃◈┃• bulb
┃◈┃• angelwings
┃◈┃• zodiac
┃◈┃• luxury
┃◈┃• paint
┃◈┃• frozen
┃◈┃• castle
┃◈┃• tatoo
┃◈┃• valorant
┃◈┃• bear
┃◈┃• typography
┃◈┃• birthday
┃◈└───────────┈⊷
╰──────────────┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/eaqh90.jpg'
                },
                '10': {
                    title: "🏠 Main Menu 🏠",
                    content: `
╭━━━〔 Main Menu 〕━━━┈⊷
┃★╭──────────────
┃★│ ❤️ Bot Info ❤️
┃★│ • ping
┃★│ • alive
┃★│ • system
┃★│ • repo
┃★│ • owner
┃★╰──────────────
┃★╭──────────────
┃★│ ❤️ Controls ❤️
┃★│ • menu
┃★│ • menu2
┃★│ • restart
┃★╰──────────────
╰━━━━━━━━━━━━━━━┈⊷
╔══════════⚔️═══════════╗  
          *Made by Pansilu Nethmina*
           ᐯㄖ尺ㄒ乇乂 几ᗪ 爪乇几卄
╚══════════⚔️═══════════╝` ,
                    image: 'https://files.catbox.moe/qor3ew.jpg'
                }
            };

            // අංක වලට අදාළ Menu එක දෙන්න හදපු Listener එක
            const handler = async (msgData) => {
                const receivedMsg = msgData.messages[0];
                if (!receivedMsg?.message || !receivedMsg.key?.remoteJid) return;

                const isReplyToMenu = receivedMsg.message.extendedTextMessage?.contextInfo?.stanzaId === messageID;

                if (isReplyToMenu) {
                    const receivedText = receivedMsg.message.conversation || 
                                         receivedMsg.message.extendedTextMessage?.text;
                    const senderID = receivedMsg.key.remoteJid;

                    await socket.sendMessage(senderID, {
                        react: { text: '⏳', key: receivedMsg.key }
                    });

                    // User 01 කියලා යැව්වත් 1 විදිහට අරන් වැඩකරන්න හදපු එක
                    const cleanText = receivedText ? receivedText.trim().replace(/^0+/, '') : '';

                    if (menuData[cleanText]) {
                        const selectedMenu = menuData[cleanText];
                        
                        await socket.sendMessage(
                            senderID,
                            {
                                image: { url: selectedMenu.image },
                                caption: selectedMenu.content,
                                contextInfo: contextInfo
                            },
                            { quoted: receivedMsg }
                        );

                        await socket.sendMessage(senderID, {
                            react: { text: '✅', key: receivedMsg.key }
                        });

                    } else {
                        await socket.sendMessage(
                            senderID,
                            {
                                text: `❌ *Invalid Option!* ❌\n\nPlease reply with a number between 1-10 to select a menu.\n\n*Example:* Reply with "1" for Download Menu`,
                                contextInfo: contextInfo
                            },
                            { quoted: receivedMsg }
                        );

                        await socket.sendMessage(senderID, {
                            react: { text: '❌', key: receivedMsg.key }
                        });
                    } 
                } 
            }; 
            
            // Listener එක on කිරීම
            socket.ev.on("messages.upsert", handler);
            
            // විනාඩි 5 කට පස්සේ listener එක අයින් කරනවා (Memory Leak නවත්තන්න)
            setTimeout(() => {
                socket.ev.off("messages.upsert", handler);
            }, 300000);

        } catch (error) {
            console.error('Menu Error:', error);
            await socket.sendMessage(sender, { 
                text: `❌ Error in Menu System: ${error.message}` 
            }, { quoted: msg });
        }
    }
};
