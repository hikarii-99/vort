const axios = require('axios');
const fs = require('fs');
const os = require('os');
const path = require('path');

module.exports = {
    command: ['ig', 'igdl', 'instagram', 'reel', 'insta'],
    description: 'Download Instagram Reels or Posts',
    ownerOnly: false,

    handler: async ({ socket, msg, sender, args }) => {
        try {
            const urlInput = args[0];

            if (!urlInput || !urlInput.includes('instagram.com')) {
                return await socket.sendMessage(sender, {
                    text: "❌ Please provide a valid Instagram video URL!\n📌 *Example:* `.ig https://www.instagram.com/reel/DY4aQWMgUb-/`"
                }, { quoted: msg });
            }

            // Waiting Reaction
            await socket.sendMessage(sender, { react: { text: '⏳', key: msg.key } });

            // PoddaX IG API Request
            const apiUrl = `https://poddax-api.dev/instagram?url=${encodeURIComponent(urlInput)}`;
            const { data } = await axios.get(apiUrl, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
                }
            });

            if (!data || !data.success || !data.url) {
                await socket.sendMessage(sender, { react: { text: '❌', key: msg.key } });
                return await socket.sendMessage(sender, {
                    text: "❌ Failed to fetch video details. Please check the link and try again!"
                }, { quoted: msg });
            }

            // Downloading Reaction
            await socket.sendMessage(sender, { react: { text: '⬇️', key: msg.key } });

            const fileName = `ig_video_${Date.now()}.mp4`;
            const filePath = path.join(os.tmpdir(), fileName);

            // Download Video Stream
            const response = await axios({
                url: data.url,
                method: 'GET',
                responseType: 'stream'
            });

            const writer = fs.createWriteStream(filePath);
            response.data.pipe(writer);

            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            const caption = `🎬 *VORTEX MD INSTAGRAM DOWNLOADER* 🎬\n\n` 
                            
                            ;

            // Send Video to User
            await socket.sendMessage(sender, {
                video: { url: filePath },
                mimetype: 'video/mp4',
                caption: caption
            }, { quoted: msg });

            // Delete Temp File
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }

            // Success Reaction
            await socket.sendMessage(sender, { react: { text: '✅', key: msg.key } });

        } catch (error) {
            console.error("Instagram Command Error:", error);
            await socket.sendMessage(sender, { react: { text: '❌', key: msg.key } });
            await socket.sendMessage(sender, { 
                text: `❌ Error: ${error.message}` 
            }, { quoted: msg });
        }
    }
};
